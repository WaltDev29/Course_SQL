package mvc_jdbc_test.entity;

public abstract class Entity {
    public abstract String getId();
}
